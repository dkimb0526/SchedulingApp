import React, { useState, useEffect } from "react";
import axios from "axios";
import SlotList from "./SlotList";
import SlotDetail from "./SlotDetail";
import AddSlotForm from "./AddSlotForm";

const CoachView = ({ coachId }) => {
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);

  const fetchSlots = () => {
    axios
      .get(`/api/coaches/${coachId}`)
      .then((response) => setSlots(response.data.slots))
      .catch((error) => console.error("Error fetching slots:", error));
  };

  useEffect(() => {
    fetchSlots();
  }, [coachId]);

  const handleSelectSlot = (slot) => {
    setSelectedSlot(slot);
  };

  const handleUpdateSlot = (updatedSlot) => {
    fetchSlots();
    setSelectedSlot(updatedSlot);
  };

  const upcomingBookedSlots = slots.filter(
    (slot) => slot.studentId && new Date(slot.startTime) > new Date()
  );
  const emptySlots = slots.filter(
    (slot) => !slot.studentId && new Date(slot.startTime) > new Date()
  );
  const pastSessions = slots.filter(
    (slot) => new Date(slot.startTime) < new Date()
  );

  return (
    <div>
      <h2>Coach View</h2>
      <AddSlotForm coachId={coachId} />
      <h3>Upcoming Booked Slots</h3>
      <SlotList slots={upcomingBookedSlots} onSelectSlot={handleSelectSlot} />
      <h3>Empty Slots</h3>
      <SlotList slots={emptySlots} onSelectSlot={handleSelectSlot} />
      <h3>Past Sessions</h3>
      <SlotList slots={pastSessions} onSelectSlot={handleSelectSlot} />
      {selectedSlot && (
        <SlotDetail slot={selectedSlot} onUpdateSlot={handleUpdateSlot} />
      )}
    </div>
  );
};

export default CoachView;
