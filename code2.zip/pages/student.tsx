import React from "react";
import StudentView from "../components/StudentView";

const StudentPage = () => {
  return <StudentView />;
};

export default StudentPage;
