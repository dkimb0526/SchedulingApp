import Link from "next/link";
import { useState, useEffect } from "react";
import axios from "axios";

const HomePage = () => {
  const [coaches, setCoaches] = useState([]);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios
      .get("/api/coaches")
      .then((response) => setCoaches(response.data))
      .catch((error) => console.error("Error fetching coaches:", error));

    axios
      .get("/api/students")
      .then((response) => setStudents(response.data))
      .catch((error) => console.error("Error fetching students:", error));
  }, []);

  return (
    <div>
      <h1>Home Page</h1>
      <h2>Coaches</h2>
      <ul>
        {coaches.map((coach) => (
          <li key={coach.id}>
            <Link href={`/coaches/${coach.id}`}>{coach.name}</Link>
          </li>
        ))}
      </ul>
      <h2>Students</h2>
      <ul>
        {students.map((student) => (
          <li key={student.id}>
            <Link href={`/students/${student.id}`}>{student.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default HomePage;
