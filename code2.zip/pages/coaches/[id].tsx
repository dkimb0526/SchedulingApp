import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import axios from "axios";
import SlotList from "../../components/SlotList";
import AddSlotForm from "../../components/AddSlotForm";

const CoachPage = () => {
  const router = useRouter();
  const { id } = router.query;
  const [coach, setCoach] = useState(null);

  useEffect(() => {
    if (id) {
      axios
        .get(`/api/coaches/${id}`)
        .then((response) => setCoach(response.data))
        .catch((error) => console.error("Error fetching coach data:", error));
    }
  }, [id]);

  if (!coach) return <p>Loading...</p>;

  const { slots } = coach;
  const upcomingBookedSlots = slots.filter(
    (slot) => slot.studentId && new Date(slot.startTime) > new Date()
  );
  const emptySlots = slots.filter(
    (slot) => !slot.studentId && new Date(slot.startTime) > new Date()
  );
  const pastSessions = slots.filter(
    (slot) => new Date(slot.startTime) < new Date()
  );

  return (
    <div>
      <h1>{coach.name}</h1>
      <h2>Upcoming Booked Slots</h2>
      <SlotList slots={upcomingBookedSlots} role="coach" />
      <h2>Empty Slots</h2>
      <SlotList slots={emptySlots} role="coach" />
      <h2>Past Sessions</h2>
      <SlotList slots={pastSessions} role="coach" />
      <AddSlotForm coachId={Number(id)} />{" "}
      {/* Ensure coachId is passed as a prop */}
    </div>
  );
};

export default CoachPage;
