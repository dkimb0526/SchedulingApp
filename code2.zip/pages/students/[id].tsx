import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import axios from "axios";
import SlotList from "../../components/SlotList";

const StudentPage = () => {
  const router = useRouter();
  const { id } = router.query;
  const [student, setStudent] = useState(null);

  useEffect(() => {
    if (id) {
      axios
        .get(`/api/students/${id}`)
        .then((response) => setStudent(response.data))
        .catch((error) => console.error("Error fetching student data:", error));
    }
  }, [id]);

  if (!student) return <p>Loading...</p>;

  const { slots } = student;
  const availableSlots = slots.filter((slot) => !slot.studentId);
  const upcomingSlots = slots.filter(
    (slot) =>
      slot.studentId === student.id && new Date(slot.startTime) > new Date()
  );

  return (
    <div>
      <h1>{student.name}</h1>
      <h2>Available Slots</h2>
      <SlotList slots={availableSlots} role="student" />
      <h2>Your Upcoming Slots</h2>
      <SlotList slots={upcomingSlots} role="student" />
    </div>
  );
};

export default StudentPage;
